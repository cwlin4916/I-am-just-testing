# TTS

## single-speaker TTS

Use MMS.
It is a single-speaker TTS model.
Just run on all the text data.

## Multi-speaker TTS
We try multilingual TTS with voice cloning.
VCTK consists of 109 speakers.
We use 10 speakers for dev and test.
5 male + 5 female.
For source audios, choose as long as possible.
We will synthesize training samples using all the other 89 speakers.
