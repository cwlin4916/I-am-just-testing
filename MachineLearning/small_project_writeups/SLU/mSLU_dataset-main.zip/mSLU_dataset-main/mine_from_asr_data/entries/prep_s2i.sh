python mine_from_asr_data/prep_s2i.py \
  /export/b12/cmeng9/mSLU_dataset/mine_from_asr_data/output/text_mining/massive_cv/en/meta/TH-1.0.bitext.0.bitext.tsv.gz \
  /export/b12/cmeng9/mSLU_dataset/mine_from_asr_data/output/text_mining/massive_cv/en/s2i.1.09.csv \
  /export/b12/cmeng9/mSLU_dataset/text_to_speech/output/xtts/massive/en-US/s2i_data/intent.dict
